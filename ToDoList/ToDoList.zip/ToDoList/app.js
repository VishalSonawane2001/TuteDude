const express = require('express');
const bodyParser = require('body-parser');
let app = express();
app.set('view engine', 'ejs');

app.use(express.static("Public"));//css connection

app.use(express.urlencoded({ extended: true }));
let items=[];
// let example="working";
app.get("/", function(req, res) {
    res.render("list",{ejes: items})
});
app.post("/", function(req, res) {
    let item = req.body.ele1;
    items.push(item);
    res.redirect("/");
});

app.listen(8000, function() {
    console.log("Server started on port 8000");
});